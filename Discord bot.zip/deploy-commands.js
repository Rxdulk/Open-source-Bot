const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath);
  if ('data' in command && 'execute' in command) {
    commands.push(command.data.toJSON());
    console.log(`✓ Loaded command: ${command.data.name}`);
  } else {
    console.log(`✗ [WARNING] The command at ${filePath} is missing a required "data" or "execute" property.`);
  }
}

const token = process.env.DISCORD_BOT_TOKEN;
const clientId = process.env.DISCORD_CLIENT_ID;

if (!token || !clientId) {
  console.error('\n════════════════════════════════════════');
  console.error('✗ ERROR: Missing required environment variables!');
  console.error('────────────────────────────────────────');
  console.error('Please set in your .env file:');
  console.error('  DISCORD_BOT_TOKEN=your_token_here');
  console.error('  DISCORD_CLIENT_ID=your_client_id_here');
  console.error('\nYou can copy .env.example and fill in your values:');
  console.error('  cp .env.example .env');
  console.error('════════════════════════════════════════\n');
  process.exit(1);
}

const rest = new REST().setToken(token);

(async () => {
  try {
    console.log(`\n════════════════════════════════════════`);
    console.log(`Deploying ${commands.length} slash commands...`);
    console.log(`════════════════════════════════════════\n`);
    
    const data = await rest.put(
      Routes.applicationCommands(clientId),
      { body: commands },
    );

    console.log(`\n✓ Successfully deployed ${data.length} application (/) commands!`);
    console.log('Commands are now available globally in Discord\n');
  } catch (error) {
    console.error('\n✗ Error deploying commands:');
    console.error(error);
    process.exit(1);
  }
})();
