HOW TO SETUP YOUR BOT! (please follow these steps carefully)
    SETUP:
   *- Go to Discord Developer Portal and create an application (add pfp or banner if wanted)
   *- Reset your bot token and copy it
    SETTING UP THE .env FILE:
   *- Take your bot token and replace {your bot token here} with your bot token (remove the { } too)
    HOSTING:
   *- Recommend method : Local hosting/Termux
     +First set up your files, type Termux-file-setup (or similar) 
     + Now navigate to your bot file (the one with index.js), type - cd storage/shared/your bot file -
     + If done correctly after you run - node index.js - it should say "Bot is connected" or similar
     FAQ*
 Q : Why is there no commands?
 A : Because you didn't run - node deploy-commands.js -
 Q : Why did it says "Application did not respond" after running the commands?
 A : Because it isn't online, rehost the bot if possible
 Q : Why is it asking for my bot's token
 A : What? that is nessescery cmon