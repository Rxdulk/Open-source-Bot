const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('meme')
    .setDescription('Get a random meme from r/memes'),
  async execute(interaction) {
    await interaction.deferReply();

    try {
      const response = await fetch('https://meme-api.com/gimme/memes');
      const data = await response.json();

      if (!data.url) {
        return await interaction.editReply({ content: 'Failed to fetch a meme. Try again!' });
      }

      const embed = new EmbedBuilder()
        .setTitle(data.title)
        .setImage(data.url)
        .setURL(data.postLink)
        .setColor('#FF6B6B')
        .setFooter({ text: `Posted by u/${data.author} • r/${data.subreddit}` })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      await interaction.editReply({ content: 'Error fetching meme. Try again later!' });
    }
  },
};
