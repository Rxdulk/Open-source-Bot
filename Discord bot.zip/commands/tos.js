const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tos')
    .setDescription('View the Terms of Service'),
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('Here are your Term of Service')
      .setDescription('Please read our Terms of Service carefully.\n\n[Click here to view the Terms of Service](https://docs.google.com/document/d/1CQUFR4J4hLKvDelSVubVzGKF3bIhLG-yaGtOiVR2RCE/edit?usp=drivesdk)')
      .setColor('#0099ff')
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
