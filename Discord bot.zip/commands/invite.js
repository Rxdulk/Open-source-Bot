const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invite')
    .setDescription('Get the bot invite link to add it to your server'),
  async execute(interaction) {
    try {
      const bot = interaction.client.user;
      const inviteUrl = `https://discord.com/api/oauth2/authorize?client_id=${bot.id}&permissions=0&scope=bot%20applications.commands`;
      
      await interaction.reply({
        content: `Click the link below to add me to your server:\n${inviteUrl}`,
        ephemeral: true
      });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Failed to generate invite link.', ephemeral: true });
    }
  },
};
