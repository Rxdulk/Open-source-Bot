const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Unmute a user in the server')
    .addUserOption(option =>
      option
        .setName('target')
        .setDescription('The user to unmute')
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName('reason')
        .setDescription('Reason for the unmute')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers),
  async execute(interaction) {
    const target = interaction.options.getUser('target');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!interaction.member.permissions.has(PermissionFlagsBits.MuteMembers)) {
      return interaction.reply({ content: 'You do not have permission to unmute members!', ephemeral: true });
    }

    try {
      const member = await interaction.guild.members.fetch(target.id);
      
      if (member.id === interaction.user.id) {
        return interaction.reply({ content: 'You cannot unmute yourself!', ephemeral: true });
      }

      await member.disableCommunicationUntil(null);
      await interaction.reply({ content: `Successfully unmuted ${target.tag}. Reason: ${reason}` });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Failed to unmute the user. They may have already left the server or I lack permissions.', ephemeral: true });
    }
  },
};
