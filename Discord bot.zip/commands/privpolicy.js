const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('privpolicy')
    .setDescription('View the Privacy Policy'),
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('Here are your Privacy Policy')
      .setDescription('Please read our Privacy Policy to understand how we handle your data.\n\n[Click here to view the Privacy Policy](https://docs.google.com/document/d/1bg3g9XUpTEKTXxQFGNkCnALCy7X2-rcWnmstFGqdl2w/edit?usp=drivesdk)')
      .setColor('#0099ff')
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
