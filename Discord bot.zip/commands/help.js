const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show all available bot commands'),
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('Bot Commands')
      .setDescription('Here are all the available commands:')
      .setColor('#0099ff')
      .addFields(
        { name: '📋 Moderation Commands', value: '\u200b', inline: false },
        { name: '/ban', value: 'Ban a user from the server', inline: true },
        { name: '/kick', value: 'Kick a user from the server', inline: true },
        { name: '/warn', value: 'Warn a user (sends DM)', inline: true },
        { name: '/mute', value: 'Mute a user in the server', inline: true },
        { name: '/unmute', value: 'Unmute a user in the server', inline: true },
        { name: '/addrole', value: 'Add a role to a user', inline: true },
        { name: '/removerole', value: 'Remove a role from a user', inline: true },
        { name: '\u200b', value: '\u200b', inline: false },
        { name: '🛠️ Utility Commands', value: '\u200b', inline: false },
        { name: '/say', value: 'Make the bot send a message', inline: true },
        { name: '/embed', value: 'Create custom embedded messages', inline: true },
        { name: '/dice', value: 'Roll a dice (6/12/20 faces)', inline: true },
        { name: '/meme', value: 'Get a random meme', inline: true },
        { name: '/advice', value: 'Get random advice', inline: true },
        { name: '\u200b', value: '\u200b', inline: false },
        { name: '📖 Information & Invites', value: '\u200b', inline: false },
        { name: '/help', value: 'Show this help message', inline: true },
        { name: '/tos', value: 'View Terms of Service', inline: true },
        { name: '/privpolicy', value: 'View Privacy Policy', inline: true },
        { name: '/invite', value: 'Get bot invite link', inline: true }
      )
      .setTimestamp()
      .setFooter({ text: 'Use / to see command options' });

    await interaction.reply({ embeds: [embed] });
  },
};
