const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const advices = [
  "Don't compare your beginning to someone else's middle.",
  "The only way to do great work is to love what you do.",
  "Success is not final, failure is not fatal: it is the courage to continue that counts.",
  "Your time is limited, don't waste it living someone else's life.",
  "The future belongs to those who believe in the beauty of their dreams.",
  "It is during our darkest moments that we must focus to see the light.",
  "The only impossible journey is the one you never begin.",
  "In the middle of difficulty lies opportunity.",
  "Life is what happens when you're busy making other plans.",
  "The way to get started is to quit talking and begin doing.",
  "Don't let yesterday take up too much of today.",
  "You learn more from failure than from success.",
  "It's not whether you get knocked down, it's whether you get up.",
  "If you are working on something that you really care about, you don't have to be pushed. The vision pulls you.",
  "People who are crazy enough to think they can change the world, are the ones who do.",
  "Believe you can and you're halfway there.",
  "The best time to plant a tree was 20 years ago. The second best time is now.",
  "Do what you can, with what you have, where you are.",
  "Failure will never overtake me if my determination to succeed is strong enough.",
  "We may encounter many defeats but we must not be defeated.",
  "Knowing is not enough; we must apply. Wishing is not enough; we must do.",
  "Life has got all those twists and turns. You've got to hold on tight and believe in yourself.",
  "Keep your face always toward the sunshine, and shadows will fall behind you.",
  "Be yourself; everyone else is already taken.",
  "The only thing we have to fear is fear itself.",
  "Courage is grace under pressure.",
  "You are braver than you believe, stronger than you seem, and smarter than you think.",
  "Everything you want is on the other side of fear.",
  "The greatest glory in living lies not in never falling, but in rising every time we fall.",
  "A person who never made a mistake never tried anything new.",
  "The question isn't who is going to let me; it's who is going to stop me.",
  "You miss 100% of the shots you don't take.",
  "Whether you think you can, or you think you can't – you're right.",
  "The best revenge is massive success.",
  "Don't watch the clock; do what it does. Keep going.",
  "The only limit to our realization of tomorrow is our doubts of today.",
  "Act as if what you do makes a difference. It does.",
  "Success is walking from failure to failure with no loss of enthusiasm.",
  "Great minds discuss ideas; average minds discuss events; small minds discuss people.",
  "You are the master of your destiny. You can influence, direct and control your own environment.",
  "What lies behind us and what lies before us are tiny matters compared to what lies within us.",
  "The purpose of our lives is to be happy.",
  "Get busy living or get busy dying.",
  "It always seems impossible until it is done.",
  "Do not go where the path may lead, go instead where there is no path and leave a trail.",
  "You can't use up creativity. The more you use, the more you have.",
  "The only real limitation is the one you set in your mind.",
  "Believe in yourself and all that you are."
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('advice')
    .setDescription('Get a random piece of advice'),
  async execute(interaction) {
    const randomAdvice = advices[Math.floor(Math.random() * advices.length)];
    
    const embed = new EmbedBuilder()
      .setTitle('💡 Advice for You')
      .setDescription(randomAdvice)
      .setColor('#FFD700')
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
