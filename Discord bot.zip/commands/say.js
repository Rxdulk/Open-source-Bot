const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('say')
    .setDescription('Make the bot say something')
    .addStringOption(option =>
      option
        .setName('message')
        .setDescription('The message to send')
        .setRequired(true))
    .addChannelOption(option =>
      option
        .setName('channel')
        .setDescription('The channel to send the message to (defaults to current channel)')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction) {
    const message = interaction.options.getString('message');
    const channel = interaction.options.getChannel('channel') || interaction.channel;

    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return interaction.reply({ content: 'You do not have permission to use this command!', ephemeral: true });
    }

    if (channel.type !== ChannelType.GuildText && channel.type !== ChannelType.GuildAnnouncement) {
      return interaction.reply({ content: 'I can only send messages to text or announcement channels!', ephemeral: true });
    }

    const botPermissions = channel.permissionsFor(interaction.guild.members.me);
    if (!botPermissions.has(PermissionFlagsBits.SendMessages)) {
      return interaction.reply({ content: 'I do not have permission to send messages in that channel!', ephemeral: true });
    }

    try {
      await channel.send(message);
      await interaction.reply({ content: `Message sent to ${channel}!`, ephemeral: true });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Failed to send the message. An unexpected error occurred.', ephemeral: true });
    }
  },
};
