const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ChannelType } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Create and send an embedded message')
    .addStringOption(option =>
      option
        .setName('title')
        .setDescription('The title of the embed')
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName('text')
        .setDescription('The description/text of the embed')
        .setRequired(true))
    .addChannelOption(option =>
      option
        .setName('channel')
        .setDescription('The channel to send the embed to (defaults to current channel)')
        .setRequired(false))
    .addStringOption(option =>
      option
        .setName('color')
        .setDescription('The color of the embed (hex code like #FF5733 or color name)')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction) {
    const title = interaction.options.getString('title');
    const text = interaction.options.getString('text');
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const color = interaction.options.getString('color') || '#0099ff';

    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return interaction.reply({ content: 'You do not have permission to use this command!', ephemeral: true });
    }

    if (channel.type !== ChannelType.GuildText && channel.type !== ChannelType.GuildAnnouncement) {
      return interaction.reply({ content: 'I can only send embeds to text or announcement channels!', ephemeral: true });
    }

    const botPermissions = channel.permissionsFor(interaction.guild.members.me);
    if (!botPermissions.has(PermissionFlagsBits.SendMessages) || !botPermissions.has(PermissionFlagsBits.EmbedLinks)) {
      return interaction.reply({ content: 'I do not have permission to send messages or embeds in that channel!', ephemeral: true });
    }

    try {
      const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(text)
        .setColor(color)
        .setTimestamp()
        .setFooter({ text: `Sent by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

      await channel.send({ embeds: [embed] });
      await interaction.reply({ content: `Embed sent to ${channel}!`, ephemeral: true });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Failed to send the embed. Please check the color format or channel permissions.', ephemeral: true });
    }
  },
};
