const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a user')
    .addUserOption(option =>
      option
        .setName('target')
        .setDescription('The user to warn')
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName('reason')
        .setDescription('Reason for the warning')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    const target = interaction.options.getUser('target');
    const reason = interaction.options.getString('reason');

    if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ content: 'You do not have permission to warn members!', ephemeral: true });
    }

    try {
      const member = await interaction.guild.members.fetch(target.id);
      
      if (member.id === interaction.user.id) {
        return interaction.reply({ content: 'You cannot warn yourself!', ephemeral: true });
      }

      if (member.roles.highest.position >= interaction.member.roles.highest.position) {
        return interaction.reply({ content: 'You cannot warn someone with an equal or higher role!', ephemeral: true });
      }

      if (member.roles.highest.position >= interaction.guild.members.me.roles.highest.position) {
        return interaction.reply({ content: 'I cannot warn someone with an equal or higher role than me!', ephemeral: true });
      }

      await member.send(`You have been warned in ${interaction.guild.name}. Reason: ${reason}`).catch(() => {
        console.log(`Could not DM ${target.tag}`);
      });

      await interaction.reply({ content: `Successfully warned ${target.tag}. Reason: ${reason}` });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Failed to warn the user. They may have already left the server.', ephemeral: true });
    }
  },
};
