const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dice')
    .setDescription('Roll a dice')
    .addIntegerOption(option =>
      option
        .setName('faces')
        .setDescription('Number of faces (6, 12, or 20)')
        .setRequired(false)
        .addChoices(
          { name: '6 faces', value: 6 },
          { name: '12 faces', value: 12 },
          { name: '20 faces', value: 20 }
        )),
  async execute(interaction) {
    const faces = interaction.options.getInteger('faces') || 6;
    const result = Math.floor(Math.random() * faces) + 1;

    const embed = new EmbedBuilder()
      .setTitle('🎲 Dice Roll')
      .setDescription(`You rolled a **${faces}-sided dice** and got: **${result}**`)
      .setColor('#9B59B6')
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
