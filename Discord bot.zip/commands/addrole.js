const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('addrole')
    .setDescription('Add a role to a user')
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('The user to add the role to')
        .setRequired(true))
    .addRoleOption(option =>
      option
        .setName('role')
        .setDescription('The role to add')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  async execute(interaction) {
    const targetUser = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');

    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
      return interaction.reply({ content: 'You do not have permission to manage roles!', ephemeral: true });
    }

    if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
      return interaction.reply({ content: 'I do not have permission to manage roles!', ephemeral: true });
    }

    try {
      const member = await interaction.guild.members.fetch(targetUser.id);

      if (member.roles.highest.position >= interaction.member.roles.highest.position && interaction.guild.ownerId !== interaction.user.id) {
        return interaction.reply({ content: 'You cannot manage roles for someone with an equal or higher role!', ephemeral: true });
      }

      if (member.roles.highest.position >= interaction.guild.members.me.roles.highest.position) {
        return interaction.reply({ content: 'I cannot manage roles for someone with an equal or higher role than me!', ephemeral: true });
      }

      if (!member.manageable) {
        return interaction.reply({ content: 'I cannot manage this user. They may be the server owner or have a higher role than me.', ephemeral: true });
      }

      if (role.position >= interaction.member.roles.highest.position && interaction.guild.ownerId !== interaction.user.id) {
        return interaction.reply({ content: 'You cannot assign a role that is equal to or higher than your highest role!', ephemeral: true });
      }

      if (role.position >= interaction.guild.members.me.roles.highest.position) {
        return interaction.reply({ content: 'I cannot assign a role that is equal to or higher than my highest role!', ephemeral: true });
      }

      if (role.managed) {
        return interaction.reply({ content: 'I cannot assign this role because it is managed by an integration or bot!', ephemeral: true });
      }

      if (member.roles.cache.has(role.id)) {
        return interaction.reply({ content: `${targetUser.tag} already has the ${role.name} role!`, ephemeral: true });
      }

      await member.roles.add(role);
      await interaction.reply({ content: `Successfully added the ${role.name} role to ${targetUser.tag}!` });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Failed to add the role. The user may have left the server or I lack permissions.', ephemeral: true });
    }
  },
};
