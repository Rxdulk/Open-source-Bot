const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a user from the server')
    .addUserOption(option =>
      option
        .setName('target')
        .setDescription('The user to kick')
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName('reason')
        .setDescription('Reason for the kick')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  async execute(interaction) {
    const target = interaction.options.getUser('target');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!interaction.member.permissions.has(PermissionFlagsBits.KickMembers)) {
      return interaction.reply({ content: 'You do not have permission to kick members!', ephemeral: true });
    }

    try {
      const member = await interaction.guild.members.fetch(target.id);
      
      if (member.id === interaction.user.id) {
        return interaction.reply({ content: 'You cannot kick yourself!', ephemeral: true });
      }

      if (member.roles.highest.position >= interaction.member.roles.highest.position) {
        return interaction.reply({ content: 'You cannot kick someone with an equal or higher role!', ephemeral: true });
      }

      if (member.roles.highest.position >= interaction.guild.members.me.roles.highest.position) {
        return interaction.reply({ content: 'I cannot kick someone with an equal or higher role than me!', ephemeral: true });
      }

      if (!member.kickable) {
        return interaction.reply({ content: 'I cannot kick this user. They may be the server owner or have a higher role than me.', ephemeral: true });
      }

      await member.kick(reason);
      await interaction.reply({ content: `Successfully kicked ${target.tag}. Reason: ${reason}` });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Failed to kick the user. They may have already left the server or I lack permissions.', ephemeral: true });
    }
  },
};
