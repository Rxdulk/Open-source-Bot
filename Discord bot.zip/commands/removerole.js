const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('removerole')
    .setDescription('Remove a role from a user')
    .addUserOption(option =>
      option
        .setName('user')
        .setDescription('The user to remove the role from')
        .setRequired(true))
    .addRoleOption(option =>
      option
        .setName('role')
        .setDescription('The role to remove')
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName('reason')
        .setDescription('Reason for removing the role')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  async execute(interaction) {
    const targetUser = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
      return interaction.reply({ content: 'You do not have permission to manage roles!', ephemeral: true });
    }

    if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
      return interaction.reply({ content: 'I do not have permission to manage roles!', ephemeral: true });
    }

    try {
      const member = await interaction.guild.members.fetch(targetUser.id);

      if (member.roles.highest.position >= interaction.member.roles.highest.position && interaction.guild.ownerId !== interaction.user.id) {
        return interaction.reply({ content: 'You cannot manage roles for someone with an equal or higher role!', ephemeral: true });
      }

      if (member.roles.highest.position >= interaction.guild.members.me.roles.highest.position) {
        return interaction.reply({ content: 'I cannot manage roles for someone with an equal or higher role than me!', ephemeral: true });
      }

      if (!member.manageable) {
        return interaction.reply({ content: 'I cannot manage this user. They may be the server owner or have a higher role than me.', ephemeral: true });
      }

      if (role.position >= interaction.guild.members.me.roles.highest.position) {
        return interaction.reply({ content: 'I cannot remove a role that is equal to or higher than my highest role!', ephemeral: true });
      }

      if (!member.roles.cache.has(role.id)) {
        return interaction.reply({ content: `${targetUser.tag} does not have the ${role.name} role!`, ephemeral: true });
      }

      await member.roles.remove(role);
      await interaction.reply({ content: `Successfully removed the ${role.name} role from ${targetUser.tag}. Reason: ${reason}` });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Failed to remove the role. The user may have left the server or I lack permissions.', ephemeral: true });
    }
  },
};
