const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute a user in the server')
    .addUserOption(option =>
      option
        .setName('target')
        .setDescription('The user to mute')
        .setRequired(true))
    .addStringOption(option =>
      option
        .setName('reason')
        .setDescription('Reason for the mute')
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers),
  async execute(interaction) {
    const target = interaction.options.getUser('target');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!interaction.member.permissions.has(PermissionFlagsBits.MuteMembers)) {
      return interaction.reply({ content: 'You do not have permission to mute members!', ephemeral: true });
    }

    try {
      const member = await interaction.guild.members.fetch(target.id);
      
      if (member.id === interaction.user.id) {
        return interaction.reply({ content: 'You cannot mute yourself!', ephemeral: true });
      }

      if (member.roles.highest.position >= interaction.member.roles.highest.position) {
        return interaction.reply({ content: 'You cannot mute someone with an equal or higher role!', ephemeral: true });
      }

      if (member.roles.highest.position >= interaction.guild.members.me.roles.highest.position) {
        return interaction.reply({ content: 'I cannot mute someone with an equal or higher role than me!', ephemeral: true });
      }

      await member.disableCommunicationUntil(null, reason);
      await interaction.reply({ content: `Successfully muted ${target.tag}. Reason: ${reason}` });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Failed to mute the user. They may have already left the server or I lack permissions.', ephemeral: true });
    }
  },
};
